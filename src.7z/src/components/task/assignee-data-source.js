const assigneeDataSource = [
  {
    key:'1',
    role: "архитектор",
    cfo: 'СЦ',
    ug: "СЦ_ГСПС",
    skill: "специалист",
    plan_trz_min: "1",
    plan_trz_mid: "11",
    plan_trz_max: "111",
    cost: "70 000",
    mcp: "25",
    mcp_with_disctiunt: "22 222",
    comment: "Обучение сотрудников по использованию нового решения обработки запросов"
  },
  {
    key:'2',
    role: "дежурный негр",
    cfo: 'СЦ',
    ug: "СЦ_ГСПС",
    skill: "специалист",
    plan_trz_min: "1",
    plan_trz_mid: "11",
    plan_trz_max: "111",
    cost: "70 000",
    mcp: "-",
    mcp_with_disctiunt: "-",
    comment: "Oratio elaboraret inceptos sit altera."
  }, {
    key:'3',
    role: "технический читатель",
    cfo: 'СЦ',
    ug: "СЦ_ГСПС",
    skill: "специалист",
    plan_trz_min: "1",
    plan_trz_mid: "11",
    plan_trz_max: "111",
    cost: "70 000",
    mcp: "-",
    mcp_with_disctiunt: "-",
    comment: "Oratio elaboraret inceptos sit altera. Animal legimus reformidans venenatis quas aliquam ."
  },

]

export const assigneeTemplate =
  {
    key:'-1',
    role: "",
    cfo: '',
    ug: "",
    skill: "",
    plan_trz_min: "0",
    plan_trz_mid: "0",
    plan_trz_max: "0",
    cost: "0",
    mcp: "-",
    mcp_with_disctiunt: "",
    comment: ""

}
export default assigneeDataSource