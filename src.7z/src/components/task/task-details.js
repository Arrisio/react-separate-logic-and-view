import {DatePicker, Form, Input, Typography} from "antd";
import ModifyInfo from "../modify-info/modify-info";
const {RangePicker } = DatePicker;
const { Text, Link } = Typography;
export const TaskDetails = () => {

  return <> <Form
    initialValues={{
      name: "4) Обучение сотрудников ",
      description: "Настройка процесса взаимодействия сотрудников Заказчика с сотрудниками Исполнителя в ИС «Сервис»",
      // date_begin: d,// moment('2020-06-09T12:40:14+0000') ,
      // date_end: "2022-11-22",
      plan_trz: "67,50",
      cost: "945 000,00 ",
    }}>
    <Form.Item label="Название задачи" name={"name"}><Input/></Form.Item>


    {/*<Space direction="horizontal" size={4}>*/}
    <Form.Item><Text>Даты работ: </Text><RangePicker/></Form.Item>


    <Form.Item>
      <Form.Item label="Плановые тз (ч/д) (PERT)" name="planTz" style={{
        display: 'inline-block',
        width: 'calc(25% - 8px)',
        margin: '0 8px',
      }}><Input/></Form.Item>


      <Form.Item label="Себестоимость руб. " style={{
        display: 'inline-block',
        width: 'calc(25% - 8px)',
      }} name="cost"><Input/></Form.Item>
    </Form.Item>
    {/*</Space>*/}

    {/*        <Form.Item style={{marginBottom: 0,}}>*/}
    {/*</Form.Item>*/}

    <Form.Item label="Описание" name="description"><Input.TextArea/></Form.Item>
    <ModifyInfo/>
  </Form></>
}