import {Card, DatePicker, message, PageHeader, Typography} from "antd";
import {Content} from "antd/es/layout/layout";
import Tasks from "../tasks/tasks"

import {CopyToClipboard} from 'react-copy-to-clipboard';
import AssigneeTable from "./assignee-table";
import {TaskDetails} from "./task-details";






const Task = () => {
  const [messageApi, contextHolder] = message.useMessage();

  return <>
    <PageHeader
      title='4) Обучение сотрудников '>
      <CopyToClipboard
        text={"http://localhost:3000/forecast/task"}
         onCopy={ () => {messageApi.info('Ссылка скопирована');}}
      >
        <button><Content>Скопировать ссылку на задачу
        </Content></button></CopyToClipboard></PageHeader>
    {contextHolder}
    <Card>
      <TaskDetails/>
      <AssigneeTable/>
      <Tasks openedTaskId={'2'}/>
    </Card>
  </>
}




export default Task