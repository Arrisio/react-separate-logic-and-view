import React, { useState } from 'react';
import {
  Button,
  Form,
  Input,
  InputNumber,
  Popconfirm,
  Select,
  Table,
  Typography
} from 'antd';
import './assignee-table.css';
import AssigneeDataSource from "./assignee-data-source";
import {assigneeTemplate} from "./assignee-data-source";

const { Option } = Select;

const SelectSkills = ({text}) =><Select style={{minWidth:"200px"}} defaultValue={text}>
  <Option key={'1'} value={'джун'}></Option>
</Select>

const EditableCell = ({record, name, index, text}) => {
  // console.log('name',name,'index',index,'test',text,'record',record, "record[name]",record[name])
  return <Input defaultValue={text}>
  </Input>
}





const AssigneeTable = () => {

  const [data, setData] = useState(AssigneeDataSource);
  const [editMode, setEditModeData] = useState(false);

  const assigneeColumns = [
  { width:"5%",
    title: 'ЦФО',
    dataIndex: 'cfo',
    key:'cfo',
    render: (text, record, index)=>editMode?<EditableCell name={'cfo'} index={index} text={text}/>:text
  },
  // {width:"15%", title: 'Отдел', dataIndex: 'ug',key:'ug', render: (text, record, index)=><EditableCell name={'ug'} index={index} text={text}/>},
  {width:"25%", title: 'Отдел', dataIndex: 'ug',key:'ug', render: (text, record, index)=>editMode?<SelectSkills text={text}/>:text},
  {width:"15%",title: 'Категория', dataIndex: 'skill',key:'skill',render: (text, record, index)=>editMode?<EditableCell name={'skill'} index={index} text={text}/>:text},
  {title: 'Плановые ТЗ (ч/д)-min', dataIndex: 'plan_trz_min',key:"plan_trz_min"},
  {title: 'Плановые ТЗ (ч/д)-mid', dataIndex: 'plan_trz_mid',key:'plan_trz_mid'},
  {title: 'Плановые ТЗ (ч/д)-max', dataIndex: 'plan_trz_max',key:'plan_trz_max'},
  {title: 'Себестоимость (руб)', dataIndex: 'cost',key:"cost"},
  {title: 'МЦП', dataIndex: 'mcp',key:'mcp'},
  {title: 'МЦП со скидкой руб', dataIndex: 'mcp_with_discount',key:'mcp_with_discount'},
  {width:"35%",title: 'Комментарий', dataIndex: 'comment',  key:"comment",render: (text, record, index)=>editMode?<EditableCell name={'comment'} index={index}  text={text}/>:text},
  {title: 'Комментарий', dataIndex: 'actions',  key:"actions",render: (text, record, index)=>editMode?<EditableCell name={'comment'} index={index}  text={text}/>:text}
  ]



  const addRow = () => {
    setData([...data, {...assigneeTemplate,...{key:data.length+1}}])
  }

  return (<div>
      <Button
        onClick={()=>setEditModeData(!editMode)}
        type="primary"
        style={{
          margin: 16,
        }}
      >
        {!editMode?"В режим редактирования":"Сохранить"}
      </Button>
    {editMode&&<Button
        onClick={addRow}
        type="primary"
        style={{
          margin: 16,
        }}
      >
        Добавить исполнителя
      </Button>}

      <Table
        size={"small"}
        bordered
        dataSource={data}
        columns={assigneeColumns}
        rowClassName="editable-row"

      />

    </div>
  );
};
export default AssigneeTable