import {Form, Input, Typography} from "antd";
const { Text, Link } = Typography;

const ModifyInfo = () => {
  const data = {
    create_info: "greybo от 20.08.2018 18:21",
    modify_info: "greybo от 20.08.2018 18:21"
  }

  return <Text type="secondary">Запись создана: {data.create_info}, Последнее
    изменение: {data.modify_info}</Text>
}

//   <Form.Item  style={{          marginBottom: 0,}}   >
//       <Form.Item  label="Запись создана" style={{
//             display: 'inline-block',
//             width: 'calc(50% - 8px)',
//           }} name="create_info"><Input/></Form.Item>
//             <Form.Item label="Последнее изменение" name="modify_info" style={{
//             display: 'inline-block',
//             width: 'calc(50% - 8px)',
//             margin: '0 8px',
//           }}><Input/></Form.Item>
//     </Form.Item>
// }
export default ModifyInfo;