import {Layout, Table,PageHeader,Card } from "antd";
import {useNavigate} from 'react-router-dom';


const { Header, Footer, Sider, Content } = Layout;


export const Forecasts = () => {
  let navigate = useNavigate()
  const openForecast = e =>{
    navigate('forecast')
  }

  const columns = [
    {title: 'Номер', dataIndex: 'id'},
    {title: 'Название', dataIndex: 'name'},
    {title: 'ТО', dataIndex: 'assignee'},
    {title: 'Описание', dataIndex: 'description'},
    {title: 'Заказчик', dataIndex: 'customer'},
    // {title:'',dataIndex: ''},
  ]
  const dataSource = [
    {
      key: 1,
      name: "Прогноз11",
      id: 1111,
      assignee: "Сучков Дмитрий Валерьевич",
      customer: "Сбрбанк",
      description: "Внедрение первого этапа. Развертывание сервера, согласование шаблонов, заведение оборудования, виртуализации + ОС, обучение."
    },
    {
      key: 2,
      name: "Прогноз2",
      id: 1112,
      assignee: "Сучков Дмитрий Валерьевич",
      customer: "Сбрбанк",
      description: "Внедрение первого этапа. Развертывание сервера, согласование шаблонов, заведение оборудования, виртуализации + ОС, обучение."
    },
  ]



  return     <Layout>

      <Content>
        <Card>
          <h3>Калькулятор ТЗ</h3>
        <Table
              bordered
    size={"small"}
    columns={columns}
    dataSource={dataSource}
    onRow={(record, rowIndex) => {
    return {
        onClick: event => {
          navigate(`/forecast/${rowIndex}`)
        }
      }}}
  >

  </Table>
      </Card></Content>
    </Layout>
}

export default Forecasts