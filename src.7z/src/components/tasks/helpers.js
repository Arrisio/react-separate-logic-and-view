export const toTree = (origArr, parentId = null) => {
  const tmpArr = origArr.filter(node => node && node.parentId === parentId);
  if (tmpArr.length > 0) {
    tmpArr.sort((a, b) => a.order - b.order)
    tmpArr.forEach(elt => {
      const children = toTree(origArr, elt.key)
      if (children) {
        elt.children = children
      } else {
        delete elt.children
      }
    })
    return tmpArr
  }
}



const s = [
  {s:'s1',e:'e1'},
  {s:'s1',e:'e2'},
  {s:'s2',e:'e1'},
  {s:'s2',e:'e2'},
]

const toScopeTree = arr => {
  const tmp = []
  for (let elt of arr) {
    if (!tmp.includes(elt.s)) {
      tmp[elt.s] = {children: []}
    }
    tmp.s.children.push(elt.e)

  }
  return tmp
}