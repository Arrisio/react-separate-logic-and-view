import {Table, Typography} from 'antd';
// import update from 'immutability-helper';
import React, {useCallback, useState} from 'react';
import {DndProvider} from 'react-dnd';
import {HTML5Backend} from 'react-dnd-html5-backend';
import './tasks.css';
import {LeftOutlined, RightOutlined} from "@ant-design/icons";
import tasksData from "./tasks-data";
import {toTree} from "./helpers";
import {DraggableBodyRow} from "./draggable-body-row";


// const type = 'DraggableBodyRow';
const { Text ,Title } = Typography;

const isChild = (hoverRow, dragRow, data) => {
  if (hoverRow.parentId===null){
    console.log("hoverRow.parentId===null")
    return false
  }
  else  {
    return hoverRow.parentId === dragRow.key || isChild(data.find(elt => hoverRow.parentId === elt.key), dragRow, data)
  }
}

const getTaskRowNumber = record => {
  const prefix = record.parentId?getTaskRowNumber(tasksData.find(elt=>record.parentId===elt.key))+'.':''
  return prefix+record.order
}

const Tasks = ({openedTaskId=null}) => {
  const [data, setData] = useState(tasksData)

  const columns = [
    {
      title: '№',
      dataIndex: 'number',
      // key: 'name',
      // ellipsis:true,
      // width:"6%",
      // render: (_,record)=><Text strong={record.children} italic={record.parentId}>{getTaskRowNumber(record)}</Text >
      render: (_,record)=><Text>{getTaskRowNumber(record)}</Text >
    },
    {
      title: 'Задача',
      dataIndex: 'name',
      key: 'name',
      // ellipsis:true,
      width:"15%",
      render: (text)=><a href={"task"}><span style={{display:"block", whiteSpace: "nowrap", overflow: "hidden",textOverflow: 'ellipsis ".."'}}>{text}</span></a>
    },
    {
      title: 'Описание',
      dataIndex: 'description',
      key: 'description',
      width:"35%",
    },
    {
      title: 'Себестоимость (руб.)',
      dataIndex: 'cost',
      key: 'cost',
    },
    {
      title: 'Трз',
      dataIndex: 'trz',
      key: 'trz',
    },

    {
      title: 'тип',
      dataIndex: 'type',
      key: 'type',
    },
    {
      title: 'Даты',
      dataIndex: 'dates',
      key: 'dates',
    },
    {
      title: 'Доп.инфо',
      dataIndex: 'info',
      key: 'info',
      render: (text) => {
        if (!text) {return}
        return <>
          <p>{text.split("\n")[0]}</p>
          <p>{text.split("\n")[1]}</p>
        </>
      }
    }
  ];

  const [tree, setTree] = useState(toTree(data,openedTaskId))

  const moveLeft = record => {
    const data_ = [...data]
    const parent = data_.find(elt=>elt.key===record.parentId)
    data_.filter(elt=>parent.parentId===elt.parentId&&elt.order>parent.order).map(elt=> {
      elt.order++
    })
    data_.filter(elt=>record.parentId===elt.parentId&&elt.order>record.order).map(elt=>{
      elt.parentId=record.key;
      elt.order -= record.order
    })
    record.parentId=parent.parentId
    record.order=parent.order+1
    data_.sort((a, b)=>a.order-b.order)
    setData(data_)
    setTree(toTree(data_,openedTaskId))
  }

  const moveRight = record => {
    const data_ = [...data]
    const parent = data_.find(elt=>elt.parentId===record.parentId&&elt.order===record.order-1)
    // console.log(record,data)
    data_.filter(elt=>record.parentId===elt.parentId&&elt.order>record.order).map(elt=> {
       elt.order--;
    }) // сдвигаем оставшиеся на этом уровне элты на шаг вверх
    const lastNewParentChild =data_.filter(elt=>elt.parentId===parent.key).at(-1);
    const newOrder = (lastNewParentChild? lastNewParentChild.order : 0)+1;
    record.parentId = parent.key
    record.order=newOrder

    data_.sort((a, b)=>a.order-b.order)
    setData(data_)
    setTree(toTree(data_,openedTaskId))
  }


  const components = {
    body: {
      row: DraggableBodyRow,
    },
  };
  const moveRow = useCallback(
    (dragRKey, hoverRKey) => {
      const dragRow = data.find(elt => elt.key === dragRKey);
      const hoverRow = data.find(elt => elt.key === hoverRKey);
      if (isChild(hoverRow,dragRow,data)) {
        return
      }
      const data_ = [...data]
      const newDragRowOrder = hoverRow.parentId===dragRow.parentId && hoverRow.order>dragRow.order ? hoverRow.order-1 : hoverRow.order
      data_.filter(elt => (elt.parentId === dragRow.parentId && elt.order > dragRow.order)).map(elt => elt.order--)//сдвигаем вверх элты, которые лежат ниже по списку прежнего места переносимого эл-та
      data_.filter(elt => (elt.parentId === hoverRow.parentId && elt.order >= hoverRow.order)).map(elt => elt.order++)//сдвигаем вниз элты, которые будут лежать ниже бросаемого элемента
      dragRow.order = newDragRowOrder
      dragRow.parentId = hoverRow.parentId
      data_.sort((a, b) => a.order - b.order)
      // console.log(data_)
      setData(data_)
      setTree(toTree(data_,openedTaskId))
    },
    [data],
  );
  const [selectedRowKeys, setSelectedRowKeys] = useState([]);
  const onSelectChange = (newSelectedRowKeys) => {
    console.log('selectedRowKeys changed: ', newSelectedRowKeys);
    setSelectedRowKeys(newSelectedRowKeys);
  };
  const rowSelection = {
    selectedRowKeys,
    onChange: onSelectChange,
    // onChange: ()=>{console.log("rowSelection")},
    hideSelectAll:true,
    renderCell:(checked, record, index, originNode)=>{
        return <div style={{display:"flex", flexDirection: "row"  }}>
          {originNode}
          <br style={{paddingLeft:'10px'}}/>
          {record.parentId !==null && <a onClick={e=>{
            moveLeft(record)
            e.stopPropagation();
          }}> <LeftOutlined /></a>}
          {record.order>1 && <a onClick={e=>{
            e.stopPropagation();
            moveRight(record);
          }}> <RightOutlined /></a>}
      </div>}
  };

  const rowStyles = (record,index) => {
    let styleClasses = 'table-striped-rows'
    if (record.parentId) {
      styleClasses+=' table-italic-text'
    }
        if (record.children) {
      styleClasses+=' table-bold-text'
    }
    return styleClasses
  }

  return (
    <DndProvider backend={HTML5Backend}>
      <Table
        rowClassName={rowStyles}
        size="small"
        showHeader
        bordered
        columns={columns}
        expandable={{
          defaultExpandAllRows: true,
          indentSize:0,
          // rowExpandable: () => true,
          // expandedRowRender: () => {
          //   return <Variant/>
      // },
      }}
        dataSource={tree}
        components={components}
        rowSelection={rowSelection}
        onRow={(row, index) => {
          const attr = {
            index: index,
            rkey: row.key,
            moveRow,
          };
          return attr;
        }}
        pagination={false}
       />
    </DndProvider>
  );
};
export default Tasks;