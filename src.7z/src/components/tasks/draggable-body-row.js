import React, {useRef} from "react";
import {useDrag, useDrop} from "react-dnd";

const type = 'DraggableBodyRow';

export const DraggableBodyRow = ({
                                   index,
                                   rkey,
                                   moveRow,
                                   className,
                                   style,
                                   ...restProps
                                 }) => {
  const ref = useRef(null);
  const [{isOver, dropClassName}, drop] = useDrop({

    accept: type,
    collect: (monitor) => {
      let item = monitor.getItem()
      const {index: dragIndex} = monitor.getItem() || {};
      if (dragIndex === index) {
        return {};
      }
      return {
        isOver: monitor.isOver(),
        dropClassName: dragIndex < index ? ' drop-over-downward' : ' drop-over-upward',
      };
    },
    drop: (item) => {
      moveRow(item.rkey, rkey);
    },
  });
  const [, drag] = useDrag({
    type,
    item: {
      index,
      rkey,
    },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  });
  drop(drag(ref));
  return (
    <tr
      ref={ref}
      className={`${className}${isOver ? dropClassName : ''}`}
      style={{
        cursor: 'move',
        ...style,
      }}
      {...restProps}
    />
  );
};

