const  tasksData = [
    {
      key: '1',
      name: 'Аудит ИТ-инфраструктуры',
      description:"- исследуем текущие задачи ИТ служб, кто где сидит и что делает, какие обязанности и схема иерархии; - исследуем стратегии ИТ и обладминистрации, задачи которые перед ними стоят по цифровизации и тп; - исследуем текущую финансовую модель, на что и как тратят, где и кто отвечает за разработку ПО, где как и что администрирует по доменам ИТ (сети, Цоды, ВК, ИБ, ППО); - исследуем текущие задачи ИТ служб в привязке к процессам ITSM/ITIL.",
      type: "работы",
      trz:25.,
      cost: "447 500,00",
      info:"Архитектор ДВКСА- 2чд\nМанагер 10 чд\nЦФО диспетчеризации: ЦФО1\n\nЦФО менеджмента: ЦФО2 ",
      dates: '14.01.2019 - 14.01.2019 ',
      parentId: null,
      order: 2,
    },
    {
      key: '2',
      name: 'Разработка ИТ стратегии',
      description:"- исследуем ИТ сервисы; - исследуем, где и какие вычислительные мощности стоят и из чего состоят; - исследуем сетевой и инженерные домены ИТ. (здесь мы собираем картинку ASIS по технической части, как раз наше обычное обследование-аудит)",
      type: "работы",
      dates: '14.01.2019 - 14.01.2019 ',
      trz:22.,
      cost: "44 200,00",
      info:"ЦФО менеджмента: ЦФО2",
      parentId: null,
      order: 3,
    },
    {
      key: '3',
      name: 'Аудит ИТ-процессов',
      description:"Презентация, в которой описывается текущее состояние, целевое состояние, перечень проектов по достижению целевого состояния, в том числе централизованный ЦОД, верхнеуровневая оценка бюджетов проектов.",
      type: "работы",
      trz:21.,
      cost: "7500,00",
      info:"ЦФО менеджмента: ЦФО\nЦФО диспетчеризации: ЦФО1",
      dates: '14.01.2019 - 14.01.2019 ',
      parentId: null,
      order: 1,
    },
    {
      key: '5',
      name: 'Аудит ИТ-инфраструктуры Подзадача 2',
      description:"Lorem ipsum dolor sit amet, consectetur adipiscing elit. Morbi in interdum orci. Sed nulla erat, rutrum et nulla laoreet, ultrices mattis ex. Sed magna ligula, convallis posuere ipsum eget, aliquet bibendum lectus. Phasellus fermentum quis risus id posuere. Nulla nisi mauris, aliquet nec mauris et, varius mollis ex. ",
      type: "работы",
      trz:11.,
      cost: "23 000,00",
      dates: '14.01.2019 - 14.01.2019 ',
      parentId: '1',
      order: 2,
    },
    {
      key: '8',
      name: 'Аудит ИТ-инфраструктуры Подзадача 1',
      type: "работы",
      dates: '14.01.2019 - 14.01.2019 ',
      trz:1.,
      cost: "223 000,00",
      parentId: '1',
      order: 1,
    },
    {
      key: '6',
      name: 'Разработка ИТ стратегии - подзадача 2',
      type: "работы",
      dates: '14.01.2019 - 14.01.2019 ',
      trz:2.2,
      cost: "23 000,00",
      parentId: '2',
      order: 2,
    }, {
      key: '7',
      name: 'Разработка ИТ стратегии - подзадача 1',
      type: "работы",
      cost: "123 000,00",
      trz:23.,
      dates: '14.01.2019 - 14.01.2019 ',
      parentId: '2',
      order: 1,
    },
      {
      key: '9',
      name: 'Потрындеть',
      type: "сервис",
      dates: '14.01.2019 - 10.11.2022 ',
        trz:121.,
        cost: "1447 500,00",
      parentId: null,
      order: 4,
    },
  ]

// пока не надо, ибо этот  фунционал сделал в toTree
// const filterTasksByParent = (parentId=null) => {
//   if (parentId === null) return tasksData;
//   return [tasksData.find(elt=>elt.key===parentId)];
//   let tasks = [];
//   let buffer = [tasksData.find(elt=>elt.key===parentId).key];
//
//   while (buffer.length>0){
//     let children =  tasksData.filter(elt=>buffer.includes(elt.parentId))
//     buffer = children.map(elt=>elt.key)
//     tasks = [...tasks,...children]
//
//   }
//
//   return tasks;
// }

export default tasksData