import {Layout, PageHeader, Table} from "antd";
import  {DeleteOutlined, StarOutlined, StarFilled} from '@ant-design/icons'
import VariantCompact from "../variant/variant-compact";

const Variants = () => {
  const columns = [
    {title: 'Номер', dataIndex: 'id'},
    {title: 'Название', dataIndex: 'name', render: text=> <a href={"variant"}>{text}</a> },
    {title: 'Себестоимость', dataIndex: 'cost'},
    {title: 'Плановые работ ч/д', dataIndex: 'trz'},
    {title:'Описание',dataIndex: 'description'},
    {title:'Удалить',dataIndex: 'delete', render: (_,record) => <>
        <button onClick={e=>{e.stopPropagation()}}> <DeleteOutlined/></button>
        <button onClick={e=>{e.stopPropagation()}}> {record.isPrimary?<StarFilled />:<StarOutlined/> } </button>
      </>
        },
    // {title:'',dataIndex: ''},
    // {title:'',dataIndex: ''},
  ]
  const dataSource = [
    {
      key: 1,
      name: "Вариант 1 ",
      id: 1,
      cost: "1 054 500,00",
      trz: "62,00",
      description: "Внедрение первого этапа. Развертывание сервера, согласование шаблонов, заведение оборудования, виртуализации + ОС, обучение.",
      isPrimary:true,
    },
    {
      key: 2,
      name: "Вариант 2",
      id: 2,
      cost: "3 054 500,00",
      trz: "162,00",
      description: "Внедрение первого этапа. Развертывание сервера, согласование шаблонов, заведение оборудования, виртуализации + ОС, обучение.",
      isPrimary:false,
    },
    ]


  return <Table
    bordered
    size="small"

    columns={columns}
    dataSource={dataSource}
    expandable={{
      // defaultExpandAllRows: true,
      defaultExpandedRowKeys:dataSource.filter(elt=>elt.isPrimary).map(elt=>elt.key),
      rowExpandable: ()=> true,
      expandRowByClick: true,
      expandedRowRender: () => {
        return <VariantCompact/>
      },
    }}
  >
  </Table>

}

export default Variants;