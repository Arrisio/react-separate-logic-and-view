import {Col, Layout, PageHeader, Row, Table, Tabs, Typography,Card} from "antd";
import {
  Form,
  Input,

  Button,
  Radio,
  Select,
  Cascader,
  DatePicker,
  InputNumber,
  TreeSelect,
  Switch,
  Checkbox,
  Upload,
} from 'antd';

import Variants from "../variants/variants";
import ModifyInfo from "../modify-info/modify-info";

const { Title, Text } = Typography;
const {Content} = Layout;
export const Forecast = () => {
  return <>
  <PageHeader title='ТКП на создание интеграции Naumen и ИС "Сервис" (Почта Банк)'><Content>Описание какого-то прогноза</Content></PageHeader>

      <Tabs style={{margin: "0 24px"}} items={[{
        label: `Варианты`,
        key: 1,
        children: <Variants/>,
      }, {
        label: `Параметры пресейла`,
        key: 2,
        children: <ForecastDetails/>,
      }, {
        label: `История изменений`,
        key: 3,
        children: `Content of tab ${3}`,
      }
      , {
        label: `Приглашенные пользователи`,
        key: 4,
        children: `Content of tab ${4}`,
      },
        {
        label: `Настройки прогноза`,
        key: 5,
        children: <ForecastSettings/>,
      }
      ]}/>
</>
}

const ForecastSettings = () => {
  return  <Form
    labelCol={{span: 4}}
    wrapperCol={{span: 14}}
    layout="horizontal"
    initialValues={{
      unitOfMeasurement:"days",
    }}
>
 <Form.Item label="Единица измерения трудоемкости" name="unitOfMeasurement">
    <Radio.Group>
            <Radio value="days"> Ч/Д </Radio>
            <Radio value="hours"> Ч/Ч </Radio>
          </Radio.Group>
    </Form.Item>
    <Form.Item label="min FTE" name="min_fte"><Input/></Form.Item>
  </Form>
}

const ForecastDetails = () => {
  return <Form
    labelCol={{span: 4}}
    wrapperCol={{span: 14}}
    layout="horizontal"
    initialValues={{
      name:"ТКП на создание интеграции Naumen и ИС \"Сервис\"",
      hd_task:"TASK0000123",
      hd_order:"ORDER99123",
      assignee:"Почта Банк ",
      customer:"Грейбо Антон Сергеевич ",
      contract:"123-456/89",
     customer_manager:"Колдышев Павел Анатольевич",
      description:"Sale impetus quot condimentum ex fringilla ad class. Qui te omnesque eam platea fugit pri. Equidem vocent verterem maiorum posse pharetra. Imperdiet augue blandit leo adversarium libris. Cras neglegentur equidem posuere oporteat reprimique mauris mel agam iudicabit.",

    }    }
    // onValuesChange={onFormLayoutChange}
    // disabled={componentDisabled}
  >
    <Form.Item label="прогноз" name={"name"}><Input/></Form.Item>
    <Form.Item  style={{          marginBottom: 0,}}   >
      <Form.Item label="Заявка" name="hd_task" style={{
            display: 'inline-block',
            width: 'calc(50% - 8px)',
          }}><Input/></Form.Item>
      <Form.Item label="Ордер" name="hd_order" style={{
            display: 'inline-block',
            width: 'calc(50% - 8px)',
            margin: '0 8px',
          }}><Input/></Form.Item>
    </Form.Item>
    <Form.Item label="Заказчик" name="customer"><Input/></Form.Item>
    <Form.Item label="Техответсвенный" name="assignee"><Input/></Form.Item>
    <Form.Item label="Контракт" name="contract"><Input/></Form.Item>
    <Form.Item label="Менеджер заказчика" name="customer_manager"><Input/></Form.Item>
    <Form.Item  label="Описание" name="description"><Input.TextArea/></Form.Item>
    <ModifyInfo/>

  </Form>
}
export default Forecast