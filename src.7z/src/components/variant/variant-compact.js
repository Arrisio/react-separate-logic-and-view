import {Card, Tabs} from "antd";
import Tasks from "../tasks/tasks";
import VariantParams from "./variant-params";

const VariantCompact = () => {
  return <Card style={{backgroundColor: "#ebedf0"}}>
    <Tabs
      items={[
        {label: "Состав работ", key: 1, children: <Tasks/>},
        {label: "Параметры", key: 2, children: <VariantParams/>},
      ]}>
    </Tabs>
  </Card>
}
export default VariantCompact;