


import {Card,PageHeader} from "antd";
import Tasks from "../tasks/tasks";
import VariantParams from "./variant-params"


const Variant = () => {

    return <>
      <PageHeader >ИС Калькулятор ТЗ / <a>Курск (примерный расчет трз) единый ЦОД </a> / <a>Версия 4. Концепция единой службы ИТ</a></PageHeader>
      <Card>
      <VariantParams/>

      <Tasks/>
    </Card>
</>
}

export default Variant