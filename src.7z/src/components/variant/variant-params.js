import {Card, Form, Input} from 'antd'
import ModifyInfo from "../modify-info/modify-info";


const VariantParams = () => {

  return <Card><Form
        initialValues={{
      // name:"ТКП на создание интеграции Naumen и ИС \"Сервис\"",
          description:"Sale impetus quot condimentum ex fringilla ad class. Qui te omnesque eam platea fugit pri. Equidem vocent verterem maiorum posse pharetra. Imperdiet augue blandit leo adversarium libris. Cras neglegentur equidem posuere oporteat reprimique mauris mel agam iudicabit.",
          date_begin:"20.08.2018 18:21",
          date_end:"20.08.2019 18:21",
          plan_trz:"67,50" ,
          cost:"945 000,00 ",
    }} >

    <Form.Item  style={{          marginBottom: 0,}}   >
      <Form.Item  label="Себестоимость руб. " style={{
            display: 'inline-block',
            width: 'calc(50% - 8px)',
          }} name="cost"><Input/></Form.Item>
            <Form.Item label="Плановые тз (ч/д) " name="cost" style={{
            display: 'inline-block',
            width: 'calc(50% - 8px)',
            margin: '0 8px',
          }}><Input/></Form.Item>
    </Form.Item>


    {/*<Form.Item  label="Плановые тз (ч/д) " name="plan_trz"><Input/></Form.Item>*/}
    {/*<Form.Item  label="Себестоимость руб. " name="cost"><Input/></Form.Item>*/}
    <Form.Item  label="Описание" name="description"><Input.TextArea/></Form.Item>
    {/*<Form.Item label="Запись создана" name="create_info"><Input/></Form.Item>*/}
    {/*<Form.Item label="Последнее изменение" name="modify_info"><Input/></Form.Item>*/}
    <ModifyInfo/>
    </Form></Card>
}

export default VariantParams;
